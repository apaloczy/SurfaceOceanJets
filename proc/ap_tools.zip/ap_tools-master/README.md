ap_tools
========

Loose scripts and functions for personal use, mainly physical oceanography-related utilities.

dyn:      Functions to calculate dynamical quantities.

roms:     Ancillary functions to manipulate ROMS variables.

study:    Functions used in study problems.

fit:      Functions to fit statistical models to data series.

stats:    Functions for statistical calculations.

utils:    General utility functions.
